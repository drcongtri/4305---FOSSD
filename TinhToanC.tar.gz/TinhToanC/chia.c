double chia( int a, int b )
{
return a*1.0 / b*1.0;
}
