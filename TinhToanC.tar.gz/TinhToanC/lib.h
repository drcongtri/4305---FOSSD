/* lib.h */
int cong( int a, int b );
int tru( int a, int b );
long nhan( int a, int b );
double chia( int a, int b );
