#include <stdio.h>
#include "lib.h"

int main ()
{
int a, b;
printf ("Nhập vào a : ");
scanf( "%d", &a );
printf ("Nhập vào b : ");
scanf( "%d", &b );
printf( "Tổng của %d + %d = %d\n", a, b, cong( a, b ) );
printf( "Hiệu của %d - %d = %d\n", a, b, tru( a, b ) );
printf( "Tich của %d * %d = %ld\n", a, b, nhan( a, b ) );
printf( "Thương của %d / %d = %f\n", a, b, chia( a, b ) );
return 0;
}
